# Saeed AI V4.2 Backend

Run `npm install`, copy `.env.example` to `.env`, add your OpenAI API key, then run `npm start`.

Health: GET /api/health
Chat: POST /api/chat
