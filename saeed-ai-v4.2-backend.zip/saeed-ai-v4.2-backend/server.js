import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY in environment.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.use(cors());
app.use(express.json({ limit: "25mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "Saeed AI V4.2", timestamp: new Date().toISOString() });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message = "", history = [] } = req.body || {};
    const cleanMessage = String(message).trim();
    if (!cleanMessage) return res.status(400).json({ error: "Message is required." });

    const safeHistory = Array.isArray(history)
      ? history.filter(x => x && (x.role === "user" || x.role === "assistant") && typeof x.content === "string")
          .slice(-20).map(x => ({ role: x.role, content: x.content.slice(0, 12000) }))
      : [];

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      instructions: "You are Saeed AI, a helpful, professional, accurate AI assistant. Answer clearly and naturally. If the user asks in Hausa, respond in Hausa. Do not claim to have performed actions you did not perform.",
      input: [...safeHistory, { role: "user", content: cleanMessage.slice(0, 12000) }],
      store: false
    });

    res.json({ reply: response.output_text || "I could not generate a response.", responseId: response.id });
  } catch (error) {
    console.error("OpenAI error:", error);
    res.status(500).json({ error: "AI request failed.", details: process.env.NODE_ENV === "development" ? error.message : undefined });
  }
});

app.listen(PORT, () => console.log(`Saeed AI V4.2 running on port ${PORT}`));
